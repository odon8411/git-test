//
//  Num111.h
//  Nav
//
//  Created by jone on 10-8-30.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "One.h"
#import "Num1.h"
@interface Num111 : UIViewController
{
	UILabel  *label;
	UILabel  *label1;
	UIImageView *image;
	UITextView *text;
    int pageNumber;
	One *one;

}

@property (nonatomic, retain) IBOutlet UILabel *label;
@property (nonatomic, retain) IBOutlet UILabel *label1;
@property (nonatomic, retain) IBOutlet UIImageView *image;
@property (nonatomic, retain) IBOutlet UITextView *text;
@property (nonatomic, retain) IBOutlet One *one;

- (id)initWithPageNumber:(int)page;

@end
