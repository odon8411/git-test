    //
//  Two.m
//  Nav
//
//  Created by jone on 10-9-1.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Two.h"


@implementation Two
@synthesize name;
@synthesize name1;
@synthesize quote1;
@synthesize quote2;

+(id)initWithName:(NSString *)Name
{
	Two *two=[[[self alloc] init] autorelease];
	two.name=Name;
	return two;
}

+(id)initWithName:(NSString *)Name Name1:(NSString *)Name1
		   Quote1:(NSString *)Quote1  Quote2:(NSString *)Quote2
{
	Two *two=[[[self alloc] init] autorelease];
	two.name=Name;
	two.name1=Name1;
	two.quote1=Quote1;
	two.quote2=Quote2;
	return two;
}
+(id)initWithTwo:(Two *)two
{
	Two *me=[[[self alloc]init]autorelease];
	me.name=two.name;
	me.name1=two.name1;
	me.quote1=two.quote1;
	me.quote2=two.quote2;
	return me;
}

@end