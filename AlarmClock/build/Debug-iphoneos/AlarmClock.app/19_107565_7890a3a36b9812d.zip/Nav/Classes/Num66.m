    //
//  Num66.m
//  Nav
//
//  Created by jone on 10-8-31.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Num66.h"

static NSArray *__pageControlColorList = nil;
@implementation Num66
@synthesize label;
@synthesize image;
@synthesize text;

// Creates the color list the first time this method is invoked. Returns one color object from the list.
+ (UIColor *)pageControlColorWithIndex:(NSUInteger)index 
{
    if (__pageControlColorList == nil) 
	{//定义页面颜色
        __pageControlColorList = [[NSArray alloc] initWithObjects:[UIColor whiteColor], [UIColor whiteColor], [UIColor magentaColor],
                                  [UIColor blueColor], [UIColor orangeColor], [UIColor brownColor], [UIColor grayColor], nil];
    }
	
    // Mod the index by the list length to ensure access remains in bounds.
    return [__pageControlColorList objectAtIndex:index % [__pageControlColorList count]];
}

// Load the view nib and initialize the pageNumber ivar.
- (id)initWithPageNumber:(int)page 
{
    if (self = [super initWithNibName:@"Num66" bundle:nil])
	{
        pageNumber = page;
    }
    return self;
}

- (void)dealloc 
{
    [label release];
	
	[image release];
	[text release];
	
    [super dealloc];
}
/* pageNumberLabel.text = [NSString stringWithFormat:@"Page123321321321 %d", pageNumber + 1];
 self.view.backgroundColor = [MyViewController pageControlColorWithIndex:pageNumber];*/
// Set the label and background color when the view has finished loading.
- (void)viewDidLoad 
{
	image.image = [UIImage imageNamed:@"chengyu.png"];
		if (pageNumber==0)
	{
		/*label.text = [NSString stringWithFormat:@"1"];
		label.font = [UIFont italicSystemFontOfSize:20];
		label.lineBreakMode = UILineBreakModeClip;*/
	
		text.text = [NSString stringWithFormat:@"        成语是中国汉字语言词汇中一部分定型的词组或短句。成语有固定的结构形式和固定的说法，表示一定的意义，在语句中是作为一个整体来应用的。成语有很大一部分是从古代相承沿用下来的，在用词方面往往不同于现代汉语它代表了一个故事或者典故。 成语又是一种现成的话，跟习用语、谚语相近，但是也略有区别。成语大都出自书面，属于文语性质的。其次在语言形式上，成语是约定俗成的四字结构，字面不能随意更换；成语在语言表达中有生动简洁、 形象鲜明的作用。\n        所谓成语是语言中经过长期使用、锤炼而形成的固定短语。它是比词大而语法功能又相当于词的语言单位。而且富有深刻的思想内涵，简短精辟易记易用。并常常附带有感情色彩,包括贬义和褒义.　成语多数为4个字，也有3字的以及4字以上的成语，有的成语甚至是分成两部分，中间有逗号隔开。\n        成语一共有4000多条，其中96%为四字格式，也有三字、五字、六字、七字等以上成语。如五十步笑百步、闭门羹、莫须有、 欲速则不达、 醉翁之意不在酒等。成语一般用四个字,这大概是因为四字容易上口。如我国古代的诗歌总集《诗经》，就以四字句为多，古代历史《尚书》，其中四字句也有一些。后来初学读的三、百、千 ：《三字经》《百家姓》《千字文》，其中后两种即全为四字句。《四言杂字》《龙文鞭影》初、二、三集，都是四言。这虽然是训蒙书，也足以说明四字句之为人所喜爱、所乐诵。古人有些话，本来够得上警句，可以成为成语。只是因为改变为四字，比较麻烦，也就只好把它放弃，作为引导语来用。例如'宋朝范仲淹的《岳阳楼记》'，有'先天下之忧而忧，后天下之乐而乐'之语，意思很好，但因字数较多的关系，就没能形成成语，我们只能视为警句，有时可以引入文章。而如吃苦在前，享乐在后，就容易说，容易记，便可以成为成语。而同在《岳阳楼记》中的一句百废俱兴，因为是四个字，所以就成了成语。成语有很大一部分是从古代相承沿用下来的，在用词方面往往不同于现代汉语。其中有古书上的成句，也有从古人文章中压缩而成的词组，还有来自人民口里常说的习用语。有些意义从字面上可以理解，有些从字面上就不易理解,特别是典故性的。如汗牛充栋、虎踞龙蟠、东山再起、草木皆兵之类，在汉语成语里占有一定的比例。汉语历史悠久，成语特别多,这也是汉语的一个特点。"];
					 text.font = [UIFont italicSystemFontOfSize:30];
		//text.lineBreakMode = UILineBreakModeClip;
		text.editable = NO;
	}
	if (pageNumber==1) 
	{
		/*label.text = [NSString stringWithFormat:@"112312312"];
		label.font = [UIFont italicSystemFontOfSize:20];
		label.lineBreakMode = UILineBreakModeClip;*/
		
		text.text = [NSString stringWithFormat:@"Chéngyǔ (simplified Chinese: 成语; traditional Chinese: 成語, literally set phrases) are a type of traditional Chinese idiomatic expressions, most of which consist of four characters.\n Chengyu were widely used in Classical Chinese and are still common in Vernacular Chinese writing and Spoken Chinese today. According to the most stringent definition, there are about 5,000 chengyu in the Chinese language, though some dictionaries list over 20,000.Chengyu are mostly derived from ancient literature. The meaning of a chengyu usually surpasses the sum of the meanings carried by the four characters, as chengyu are often intimately linked with the myth, story or historical fact from which they were derived. As such, chengyu do not follow the usual grammatical structure and syntax of the modern Chinese spoken language, and are instead highly compact and synthetic.Many Chinese idioms have their English equivalents. For example, 冰山一角 and the tip of an iceberg` share both the literal and idiomatic meanings, while 言不由衷 and `to speak one`s tongue in one`s cheek` share the idiomatic meaning. "];
	    text.font = [UIFont italicSystemFontOfSize:30];
		//text.lineBreakMode = UILineBreakModeClip;
	}
	
	self.view.backgroundColor = [Num66 pageControlColorWithIndex:pageNumber];
}

@end
