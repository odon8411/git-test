//
//  Num1.h
//  Nav
//
//  Created by jone on 10-8-30.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SecondLevelViewController.h"
#import "/usr/include/sqlite3.h"
#import "One.h"

@interface Num1 : SecondLevelViewController 
<UITableViewDelegate, UITableViewDataSource>
{    
	sqlite3 *detabase;
		
    NSMutableArray *nameArray,*oneArray;
	//调用类one
	One *one;
	
}
@property (nonatomic)sqlite3 *database;
@property (nonatomic,retain) One *one;

@end