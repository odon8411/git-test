//
//  Num3.h
//  Nav
//
//  Created by jone on 10-8-30.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SecondLevelViewController.h"
#import "/usr/include/sqlite3.h"
#import "Two.h"
@interface Num3 : SecondLevelViewController 
<UITableViewDelegate, UITableViewDataSource>
{
	
	NSMutableArray *nameArray,*twoArray;
	sqlite3 *database;
	Two *two;
	
}
@property (nonatomic) sqlite3 *database;
@property (nonatomic,retain) Two *two;

@end
