//
//  Num88.h
//  Nav
//
//  Created by jone on 10-8-31.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface Num88 : UIViewController 
{
	UITextView *text;
	UILabel *label;
    int pageNumber;
}

@property (nonatomic, retain) IBOutlet UITextView *text;
@property (nonatomic, retain) IBOutlet UIImageView *image;
@property (nonatomic, retain) IBOutlet UILabel *label;
- (id)initWithPageNumber:(int)page;

@end
