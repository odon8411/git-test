//
//  Four.h
//  Nav
//
//  Created by jone on 10-9-1.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Four : NSObject
{
	NSString *name;
	NSString *name1;
	NSString *quote1;

}
@property(retain,nonatomic) NSString *name;
@property(retain,nonatomic) NSString *name1;
@property(retain,nonatomic) NSString *quote1;

+(id)initWithName:(NSString *)Name;
+(id)initWithName:(NSString *)Name   Name1:(NSString *)Name1
		   Quote1:(NSString *)Quote1;
+(id)initWithFour:(Four *)four;

           

@end
