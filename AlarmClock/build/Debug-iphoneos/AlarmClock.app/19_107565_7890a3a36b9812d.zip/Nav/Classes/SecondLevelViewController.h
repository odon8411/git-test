//
//  SecondLevelViewController.h
//  Nav
//
//  Created by jone on 10-8-30.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SecondLevelViewController : UITableViewController
{
	//UIImage *rowImage;
}
//@property (nonatomic, retain) UIImage *rowImage;
@end
