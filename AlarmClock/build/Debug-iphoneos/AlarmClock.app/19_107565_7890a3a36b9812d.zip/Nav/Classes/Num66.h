//
//  Num66.h
//  Nav
//
//  Created by jone on 10-8-31.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface Num66 : UIViewController 
{
	
	UILabel *label;
	UIImageView *image;
	UITextView *text;
	
    int pageNumber;
}

@property (nonatomic, retain) IBOutlet UILabel *label;

@property (nonatomic, retain) IBOutlet UIImageView *image;
@property (nonatomic, retain) IBOutlet UITextView *text;

- (id)initWithPageNumber:(int)page;

@end
