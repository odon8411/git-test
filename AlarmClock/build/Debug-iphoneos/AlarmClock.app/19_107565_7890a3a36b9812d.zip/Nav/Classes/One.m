    //
//  One.m
//  Nav
//
//  Created by jone on 10-9-1.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "One.h"


@implementation One
@synthesize name;
@synthesize name1;
@synthesize pic;
@synthesize quote1;
@synthesize name2;
@synthesize quote2;
@synthesize quote3;


+(id)initWithName:(NSString *)Name
{
	One *one=[[[self alloc]init]autorelease];
	one.name=Name;
	return one;
}
+(id)initWithName:(NSString *)Name    Name1:(NSString *)Name1
			  Pic:(NSString *)Pic    Quote1:(NSString *)Quote1
			Name2:(NSString *)Name2  Quote2:(NSString *)Quote2
           Quote3:(NSString *)Quote3 
{
	One *one=[[[self alloc]init]autorelease];
	one.name=Name;
	one.name1=Name1;
	one.pic=Pic;
	one.quote1=Quote1;
	one.name2=Name2;
	one.quote2=Quote2;
	one.quote3=Quote3;
	return one;
}

+(id)initWithOne:(One *)one
{
	One *me=[[[self alloc]init]autorelease];
	me.name=one.name;
	me.name1=one.name1;
	me.pic=one.pic;
	me.quote1=one.quote1;
	me.name2=one.name2;
	me.quote2=one.quote2;
	me.quote3=one.quote3;
	return me;
}
@end