    //
//  Num77.m
//  Nav
//
//  Created by jone on 10-8-31.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Num77.h"

static NSArray *__pageControlColorList = nil;
@implementation Num77

@synthesize label;
@synthesize image;
// Creates the color list the first time this method is invoked. Returns one color object from the list.
+ (UIColor *)pageControlColorWithIndex:(NSUInteger)index 
{
    if (__pageControlColorList == nil) 
	{//定义页面颜色
        __pageControlColorList = [[NSArray alloc] initWithObjects:[UIColor whiteColor], [UIColor whiteColor],[UIColor whiteColor], [UIColor whiteColor],
								  [UIColor whiteColor], [UIColor whiteColor],[UIColor whiteColor], [UIColor whiteColor],[UIColor whiteColor], [UIColor whiteColor], nil];
    }
	
    // Mod the index by the list length to ensure access remains in bounds.
    return [__pageControlColorList objectAtIndex:index % [__pageControlColorList count]];
}

// Load the view nib and initialize the pageNumber ivar.
- (id)initWithPageNumber:(int)page 
{
    if (self = [super initWithNibName:@"Num77" bundle:nil]) 
	{
        pageNumber = page;
    }
    return self;
}

- (void)dealloc 
{
    [label release];
	
    [super dealloc];
}
/* pageNumberLabel.text = [NSString stringWithFormat:@"Page123321321321 %d", pageNumber + 1];
 self.view.backgroundColor = [MyViewController pageControlColorWithIndex:pageNumber];*/
// Set the label and background color when the view has finished loading.
- (void)viewDidLoad 
{

	
	if (pageNumber==0)
	{
		label.text = [NSString stringWithFormat:@"退 避 三 舍"];
		label.font = [UIFont italicSystemFontOfSize:80];
		image.image = [UIImage imageNamed:@"cy_001s.png"];
	}
	if (pageNumber==1) 
	{
		label.text = [NSString stringWithFormat:@"洛 阳 纸 贵"];
		label.font = [UIFont italicSystemFontOfSize:80];
		image.image = [UIImage imageNamed:@"cy_002s.png"];
	}
	if (pageNumber==2)
	{
		label.text = [NSString stringWithFormat:@"草 木 皆 兵"];
		label.font = [UIFont italicSystemFontOfSize:80];
		image.image = [UIImage imageNamed:@"cy_003s.png"];
	}
	if (pageNumber==3) 
	{
		label.text = [NSString stringWithFormat:@"按 图 索 骥"];
		label.font = [UIFont italicSystemFontOfSize:80];
		image.image = [UIImage imageNamed:@"cy_004s.png"];
	}
	if (pageNumber==4)
	{
		label.text = [NSString stringWithFormat:@"后 来 居 上"];
		label.font = [UIFont italicSystemFontOfSize:80];
		image.image = [UIImage imageNamed:@"cy_005s.png"];
	}
	if (pageNumber==5) 
	{
		label.text = [NSString stringWithFormat:@"邯 郸 学 步"];
		label.font = [UIFont italicSystemFontOfSize:80];
		image.image = [UIImage imageNamed:@"cy_006s.png"];
	}
	if (pageNumber==6)
	{
		label.text = [NSString stringWithFormat:@"守 株 待 兔"];
		label.font = [UIFont italicSystemFontOfSize:80];
		image.image = [UIImage imageNamed:@"cy_007s.png"];
	}
	if (pageNumber==7) 
	{
		label.text = [NSString stringWithFormat:@"如 火 如 荼"];
		label.font = [UIFont italicSystemFontOfSize:80];
		image.image = [UIImage imageNamed:@"cy_008s.png"];
	}
	if (pageNumber==8)
	{
		label.text = [NSString stringWithFormat:@"望 梅 止 渴"];
		label.font = [UIFont italicSystemFontOfSize:80];
		image.image = [UIImage imageNamed:@"cy_009s.png"];
	}
	if (pageNumber==9) 
	{
		label.text = [NSString stringWithFormat:@"望 洋 兴 叹"];
		label.font = [UIFont italicSystemFontOfSize:80];
		image.image = [UIImage imageNamed:@"cy_011s.png"];
	}
	
	
	
	self.view.backgroundColor = [Num77 pageControlColorWithIndex:pageNumber];
}

@end
