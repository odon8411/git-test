    //
//  Num111.m
//  Nav
//
//  Created by jone on 10-8-30.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Num111.h"


static NSArray *__pageControlColorList = nil;
@implementation Num111

@synthesize label;
@synthesize label1;
@synthesize image;
@synthesize text;
@synthesize one;

// Creates the color list the first time this method is invoked. Returns one color object from the list.
+ (UIColor *)pageControlColorWithIndex:(NSUInteger)index 
{
    if (__pageControlColorList == nil) 
	{      //定义页面的颜色
        __pageControlColorList = [[NSArray alloc] initWithObjects:[UIColor whiteColor], [UIColor whiteColor], [UIColor whiteColor],
                                  [UIColor blueColor], [UIColor orangeColor], [UIColor brownColor], [UIColor grayColor], nil];
    }
	
    // Mod the index by the list length to ensure access remains in bounds.
    return [__pageControlColorList objectAtIndex:index % [__pageControlColorList count]];
}

// Load the view nib and initialize the pageNumber ivar.
- (id)initWithPageNumber:(int)page 
{
    if (self = [super initWithNibName:@"Num111" bundle:nil]) 
	{
        pageNumber = page;
    }
    return self;
}

- (void)dealloc 
{
    [label release];
	[label1 release];
	[image release];
	[text release];
	[one release];
	
    [super dealloc];
}

- (void)viewDidLoad 
{
	//image.image = [UIImage imageNamed:@"cy_007.jpg"];//调用数据库中的pic
	self.image.image = [UIImage imageNamed:self.one.pic];
	
	if (pageNumber==0)
	{

	
		label.text=one.name;   //调用one中的数据
		label.font=[UIFont italicSystemFontOfSize:200];
		label1.text=one.name1;
		label1.font=[UIFont italicSystemFontOfSize:40];
		text.text=one.quote1;
		text.font=[UIFont italicSystemFontOfSize:30];
		text.editable=NO;
	}
	if (pageNumber==1) 
	{
		label.text = one.name2;//调用数据库中的name2
		label.font = [UIFont italicSystemFontOfSize:30];
	
		text.text = one.quote2;//调用数据库中的quote2
		text.font = [UIFont italicSystemFontOfSize:30];
		text.editable =NO;
	}
	if (pageNumber==2)
	{
		label.text = one.name;//调用数据库中的name3
		label.font=[UIFont italicSystemFontOfSize:200];
		label1.text=one.name1;
		label1.font=[UIFont italicSystemFontOfSize:40];
		text.text = one.quote3;//调用数据库中的quote3
		text.font = [UIFont italicSystemFontOfSize:30];
		text.editable =NO;
	}
	self.view.backgroundColor = [Num111 pageControlColorWithIndex:pageNumber];
	
	NSLog(@"num111 one name %@",one.name);
}

@end
