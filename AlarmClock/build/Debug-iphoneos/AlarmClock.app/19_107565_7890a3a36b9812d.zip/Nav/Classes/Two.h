//
//  Two.h
//  Nav
//
//  Created by jone on 10-9-1.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Two : NSObject
{
	NSString *name;
	NSString *name1;
	NSString *quote1;
	NSString *quote2;

}
@property(retain,nonatomic) NSString *name;
@property(retain,nonatomic) NSString *name1;
@property(retain,nonatomic) NSString *quote1;
@property(retain,nonatomic) NSString *quote2;

+(id)initWithName:(NSString *)Name  Name1:(NSString *)Name1
		   Quote1:(NSString *)Quote1  Quote2:(NSString *)Quote2;
+(id)initWithName:(NSString *)Name;
+(id)initWithTwo:(Two *)two;
@end
