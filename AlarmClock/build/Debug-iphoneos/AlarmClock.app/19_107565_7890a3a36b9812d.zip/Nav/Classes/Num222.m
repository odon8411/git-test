    //
//  Num222.m
//  Nav
//
//  Created by jone on 10-9-2.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Num222.h"
#import "Num2.h"
static NSArray *__pageControlColorList = nil;
@implementation Num222

@synthesize label;
@synthesize label1;
@synthesize text;
@synthesize two;
// Creates the color list the first time this method is invoked. Returns one color object from the list.
+ (UIColor *)pageControlColorWithIndex:(NSUInteger)index
{
    if (__pageControlColorList == nil)
	{    //定义页面颜色
        __pageControlColorList = [[NSArray alloc] initWithObjects:[UIColor whiteColor], [UIColor whiteColor], [UIColor magentaColor],
                                  [UIColor blueColor], [UIColor orangeColor], [UIColor brownColor], [UIColor grayColor], nil];
    }
	
    // Mod the index by the list length to ensure access remains in bounds.
    return [__pageControlColorList objectAtIndex:index % [__pageControlColorList count]];
}

// Load the view nib and initialize the pageNumber ivar.
- (id)initWithPageNumber:(int)page 
{
    if (self = [super initWithNibName:@"Num222" bundle:nil])
	{
        pageNumber = page;
    }
    return self;
}

- (void)dealloc 
{
    [label release];
	[label1 release];
	[text release];
    [super dealloc];
}
/* pageNumberLabel.text = [NSString stringWithFormat:@"Page123321321321 %d", pageNumber + 1];
 self.view.backgroundColor = [MyViewController pageControlColorWithIndex:pageNumber];*/
// Set the label and background color when the view has finished loading.
- (void)viewDidLoad 
{
	label.text = two.name;//调用数据库中的name
	label.font = [UIFont italicSystemFontOfSize:200];
	label1.text = two.name1;//调用数据库中的name1
	label1.font = [UIFont italicSystemFontOfSize:40];
	if (pageNumber==0)
	{
		text.text = two.quote1;//调用数据库中的quote1
		text.font = [UIFont italicSystemFontOfSize:30];
		text.editable=NO;
	}
	if (pageNumber==1) 
	{
		text.text = two.quote2;//调用数据库中的quote2
		text.font = [UIFont italicSystemFontOfSize:30];
		text.editable = NO;
		
	}
	self.view.backgroundColor = [Num222 pageControlColorWithIndex:pageNumber];
}

@end
