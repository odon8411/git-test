//
//  Num4.h
//  Nav
//
//  Created by jone on 10-8-30.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SecondLevelViewController.h"

@interface Num4 : SecondLevelViewController 
<UITableViewDelegate, UITableViewDataSource>
{
	NSArray	*controllers;
	
}
@property (nonatomic, retain) NSArray *controllers;

@end
