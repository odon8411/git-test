//
//  ThirdLevelViewController.h
//  Nav
//
//  Created by jone on 10-9-1.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ThirdLevelViewController : UITableViewController 
{
	//UIImage *rowImage;

}
//@property (nonatomic,retain)UIImage *rowImage;
@end
