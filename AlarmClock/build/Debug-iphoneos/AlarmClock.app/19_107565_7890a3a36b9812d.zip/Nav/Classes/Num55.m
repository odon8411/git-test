    //
//  Num55.m
//  Nav
//
//  Created by jone on 10-8-31.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Num55.h"

static NSArray *__pageControlColorList = nil;
@implementation Num55
@synthesize text;
@synthesize label;
@synthesize label1;

// Creates the color list the first time this method is invoked. Returns one color object from the list.
+ (UIColor *)pageControlColorWithIndex:(NSUInteger)index 
{
    if (__pageControlColorList == nil) {//定义页面颜色
        __pageControlColorList = [[NSArray alloc] initWithObjects:[UIColor whiteColor], [UIColor whiteColor], [UIColor whiteColor],
                                  [UIColor whiteColor], [UIColor whiteColor], [UIColor brownColor], [UIColor grayColor], nil];
    }
	
    // Mod the index by the list length to ensure access remains in bounds.
    return [__pageControlColorList objectAtIndex:index % [__pageControlColorList count]];
}

// Load the view nib and initialize the pageNumber ivar.
- (id)initWithPageNumber:(int)page {
    if (self = [super initWithNibName:@"Num55" bundle:nil]) {
        pageNumber = page;
    }
    return self;
}

- (void)dealloc {
    [label release];
	[text release];
	[label1 release];
    [super dealloc];
}
/* pageNumberLabel.text = [NSString stringWithFormat:@"Page123321321321 %d", pageNumber + 1];
 self.view.backgroundColor = [MyViewController pageControlColorWithIndex:pageNumber];*/
// Set the label and background color when the view has finished loading.
- (void)viewDidLoad 
{   //定义每一个页面的内容
	label1.text = [NSString stringWithFormat:@"zhōng huá chéng yǔ zhī zuì"];
	label1.font = [UIFont italicSystemFontOfSize:40];
	if (pageNumber==0)
	{
		label.text = [NSString stringWithFormat:@"中华成语之最（一）"];
		label.font = [UIFont italicSystemFontOfSize:300];
		label.lineBreakMode = UILineBreakModeClip;
		text.text = [NSString stringWithFormat:@"最短的季节--一日三秋\n最怪的人--虎背熊腰\n最高的巨人--顶天立地\n最大的嘴--口若悬河\n最长的腿--一步登天\n最大的手--一手遮天\n最吝啬的人--一毛不拔\n最宽阔的胸怀--虚怀若谷\n最长的寿命--万寿无疆\n最宝贵的话--金玉良言\n最厉害的贼--偷天换日\n最宽的嘴巴--口若悬河\n最贵的话--一语千金\n最难的话--一言难尽\n最快的话--一言既出 驷马难追\n最重的话--一言为定\n最有价值的话--一诺千金\n最诚的忠言--金玉良言\n最大的誓言--海枯石烂\n最广的话--一言千里"];
		text.font = [UIFont italicSystemFontOfSize:40];
		text.editable = NO;
	}
	if (pageNumber==1) 
	{
		label.text = [NSString stringWithFormat:@"中华成语之最（二）"];
	    label.font = [UIFont italicSystemFontOfSize:300];
		label.lineBreakMode = UILineBreakModeClip;
		text.text = [NSString stringWithFormat:@"最有学问的人--无所不知\n最厉害的贼--偷梁换柱\n最大的差别--天壤之别\n最大的家--四海为家\n最爱学习的人--如饥似渴\n最爱工作的人--废寝忘食\n最长的时间--千秋万代\n最长的棍子--一柱擎天\n最成功的战斗--一网打尽\n最惨的结局--一败涂地\n最彻底的劳动--斩草除根\n最大的满足--天遂人愿\n最多的颜色--万紫千红\n最费时的工程--百年树人\n最繁忙的季节--多事之秋\n最公开的事情--尽人皆知\n最高明的医术--药到病除\n最高超的技术--鬼斧神工\n最高明的指挥--一呼百应\n最神秘的行动--神出鬼没"];
		text.font = [UIFont italicSystemFontOfSize:40];
		text.editable = NO;
	}
	if (pageNumber==2) 
	{
		label.text = [NSString stringWithFormat:@"中华成语之最（三）"];
	    label.font = [UIFont italicSystemFontOfSize:300];
		label.lineBreakMode = UILineBreakModeClip;
		text.text = [NSString stringWithFormat:@"最小的针--无孔不入\n最大的变化--天翻地覆\n最怪的动物--虎头蛇尾\n最大的容量--包罗万象\n最大的差别--天壤之别\n最难做的饭--无米之炊\n最大的变化--天翻地覆\n最快的速度--风驰电掣\n最公开的事情--尽人皆知\n最短的季节--一日三秋\n最大的手术--脱胎换骨\n最宽的视野--一览无余\n最大的冒险--孤注一掷\n最大的树叶--一叶障目\n最大的声响--惊天动地\n最高的瀑布--一落千丈\n最错的追求--南辕北辙\n最远的地方--天涯海角\n最大的进展--一步登天\n最荒的地方--不毛之地"];
		text.font = [UIFont italicSystemFontOfSize:40];
		text.editable = NO;
	}
	if (pageNumber==3) 
	{
		label.text = [NSString stringWithFormat:@"中华成语之最（四）"];
	    label.font = [UIFont italicSystemFontOfSize:300];
		label.lineBreakMode = UILineBreakModeClip;
		text.text = [NSString stringWithFormat:@"最险的时候--千钧一发\n最离奇的想法--异想天开\n最大的本领--开天辟地\n最反常的气候--晴天霹雳\n最昂贵的稿费--一字千金\n最小的邮筒--难以置信\n最长的句子--文不加点\n最大的被子--铺天盖地\n最大的空间--无边无际\n最大的影集--包罗万象\n最大的幸运--九死一生\n最好的生意--一本万利\n最绝望的前途--山穷水尽\n最远的分离--天壤之别\n最繁忙的航空港--日理万机\n最彻底的美容术--面目全非\n最长的一天--度日如年\n最好的司机--驾轻就熟\n最好的药方--灵丹妙药\n最好的箭术--一箭双雕"];
		text.font = [UIFont italicSystemFontOfSize:40];
		text.editable = NO;
	}
	if (pageNumber==4) 
	{
		label.text = [NSString stringWithFormat:@"中华成语之最（五）"];
	    label.font = [UIFont italicSystemFontOfSize:300];
		label.lineBreakMode = UILineBreakModeClip;
		text.text = [NSString stringWithFormat:@"最有用的衣冠--优孟衣冠\n最危险的差使--与虎谋皮\n最正直的人--正人君子\n最高点--至高无上\n最南的捷径--终南捷径\n最难做的菜--众口难调\n最傻的嫌犯--自投罗网\n最不管事的和尚--做一天和尚撞一天钟\n最公开的事情--尽人皆知\n最荒凉的地方--不毛之地\n最悬殊的地方--天渊之别\n最反常的地方--青天霹雳\n最宽阔的地方--虚怀入谷\n最远的分离--天壤之别\n最昂贵的稿费--一字千金\n最绝望的前途--山穷水尽\n最高的人--顶天立地\n最大的地方--无边无际\n最长的寿命--万寿无疆\n最有学问的人--博古通今\n最珍贵的东西--凤毛麟角"];
		text.font = [UIFont italicSystemFontOfSize:40];
		text.editable = NO;
	}
	self.view.backgroundColor = [Num55 pageControlColorWithIndex:pageNumber];
}

@end
