    //
//  Num3.m
//  Nav
//
//  Created by jone on 10-8-30.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Num3.h"
#import "Num33.h"

#import "NavAppDelegate.h"

@implementation Num3
@synthesize two;
@synthesize database;

- (void)viewDidLoad
{
	
	self.tableView.delegate=self;
	
	twoArray=[[NSMutableArray alloc]init];
	//打开数据库
	NSString *path=[NSString stringWithFormat:@"%@%@",
					[[NSBundle mainBundle] resourcePath],@"/database"];
	if (sqlite3_open([path UTF8String], &database) != SQLITE_OK) 
	{
		sqlite3_close(database);
		NSAssert(0,@"Failed to open database");
	}
	
	NSString *query = @"select id , name, name1, quote1, quote2 from three order by name";
	sqlite3_stmt  *statement;
	if(sqlite3_prepare_v2(database,[query UTF8String],-1,&statement,nil)==SQLITE_OK)
	{
		
		
		while(sqlite3_step(statement) == SQLITE_ROW)
		{
			char *name0=(char*) sqlite3_column_text(statement,1);
			char *name10=(char*) sqlite3_column_text(statement, 2);
			char *quote10=(char*) sqlite3_column_text(statement, 3);
			char *quote20=(char*) sqlite3_column_text(statement, 4);
			
			
			NSString *name=[[NSString alloc] initWithUTF8String:name0];
			NSString *name1=[[NSString alloc] initWithUTF8String:name10];
			NSString *quote1=[[NSString alloc] initWithUTF8String:quote10];
			NSString *quote2=[[NSString alloc] initWithUTF8String:quote20];
			//将数据录入到two
			[twoArray addObject: [Two initWithName: name Name1:name1 Quote1:quote1 Quote2:quote2]];			
		
			
		}
		//关闭数据库
		sqlite3_finalize(statement);
	}
	
	[super viewDidLoad];
	
}

- (void)dealloc 
{
    [two release];
	[super dealloc];
}

#pragma mark -
#pragma mark Table Data Source Methods
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return [twoArray count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	
	static NSString *TopLevelCellIdentifier = @"成语小知识";
	
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:TopLevelCellIdentifier];
	if (cell == nil)
	{
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:TopLevelCellIdentifier] autorelease];
	}
	// Configure the cell
	NSUInteger row = [indexPath row];
	Two *two = [twoArray objectAtIndex:indexPath.row];
	
	NSString *name = two.name;
	cell.text=name;
	return cell;
	
}

#pragma mark -
#pragma mark Table View Delegate Methods


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
	//row指点击中哪一行，从0开始
	//NSUInteger row = [indexPath row];
	//如下写上跳转代码
	NavAppDelegate *delegate=[[UIApplication sharedApplication]delegate];
	Num33 *nextController = [[Num33 alloc]
										initWithNibName:@"Num33" bundle:nil];
	//from two to num33
	NSUInteger row = [indexPath row];
	Two *two_trans = [twoArray objectAtIndex:indexPath.row];
	nextController.two=two_trans;
	
	NSLog(@"num3 two name %@",two_trans.name);
	
	[delegate.navController pushViewController:nextController animated:YES];
	
	
}
@end

