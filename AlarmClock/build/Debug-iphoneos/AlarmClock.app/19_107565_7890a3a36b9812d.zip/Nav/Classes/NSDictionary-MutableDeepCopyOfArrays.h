#import <UIKit/UIKit.h>

@interface NSDictionary(MutableDeepCopyOfArrays)
- (NSMutableDictionary *)mutableDeepCopyOfArrays;
- (NSMutableDictionary *)mutableDeepCopy;
@end