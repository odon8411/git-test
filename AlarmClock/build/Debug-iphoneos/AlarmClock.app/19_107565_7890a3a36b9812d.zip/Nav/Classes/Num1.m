    //
//  Num1.m
//  Nav
//
//  Created by jone on 10-8-30.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Num1.h"
#import "Num11.h"
#import "NavAppDelegate.h"


@implementation Num1
@synthesize database;
@synthesize one;

- (void)viewDidLoad 
{
	self.tableView.delegate=self;
	self.title=one.name;	
	oneArray=[[NSMutableArray alloc]init];
	//打开数据库
	NSString *path=[NSString stringWithFormat:@"%@%@",
					[[NSBundle mainBundle] resourcePath],@"/database"];
	if (sqlite3_open([path UTF8String], &database) != SQLITE_OK) 
	{
		sqlite3_close(database);
		NSAssert(0,@"Failed to open database");
	}
	
	//获取数据
	NSString *query = @"select id, name,name1,pic,quote1,name2,quote2,quote3   from one order by name";//查找表中的数据，行和每一行对应的值
	sqlite3_stmt *statement;
	if(sqlite3_prepare_v2(database, [query UTF8String], -1, &statement, nil) == SQLITE_OK)
	{
		
		
		while(sqlite3_step(statement) == SQLITE_ROW)
		{
			
			char *name0 =(char*) sqlite3_column_text(statement, 1);
			char *name10=(char*) sqlite3_column_text(statement, 2);
			char *pic0=(char*) sqlite3_column_text(statement, 3);
			char *quote10=(char*) sqlite3_column_text(statement, 4);
			char *name20=(char*) sqlite3_column_text(statement, 5);
			char *quote20=(char*) sqlite3_column_text(statement, 6);
			char *quote30=(char*) sqlite3_column_text(statement, 7);
			NSString *name=[[NSString alloc] initWithUTF8String:name0];	
			NSString *name1=[[NSString alloc] initWithUTF8String:name10];
			NSString *pic=[[NSString alloc] initWithUTF8String:pic0];
			NSString *quote1=[[NSString alloc] initWithUTF8String:quote10];
			NSString *name2=[[NSString alloc] initWithUTF8String:name20];
			NSString *quote2=[[NSString alloc] initWithUTF8String:quote20];
			NSString *quote3=[[NSString alloc] initWithUTF8String:quote30];
			
			
		    //将数据库的数组放入到one这个类中
			[oneArray addObject: [One initWithName:name Name1:name1 Pic:pic Quote1:quote1 Name2:name2 Quote2:quote2 Quote3:quote3]];
			
		}
		
		sqlite3_finalize(statement);
	}
	//关闭数据库
	
	[super viewDidLoad];
}


- (void)dealloc 
{
	[one release];
	[super dealloc];
	
}

#pragma mark -
#pragma mark Table View Data Source Methods
//返回同一类别的行数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return [oneArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
	static NSString *TopLevelCellIdentifier = @"经典成语故事";
	
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:TopLevelCellIdentifier];
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:TopLevelCellIdentifier] autorelease];
	}
	// Configure the cell
//	NSUInteger row = [indexPath row];
	One *one = [oneArray objectAtIndex:indexPath.row];
	//选取one中的name
	NSString *name = one.name;
	cell.text=name;
	
	return cell;
}

#pragma mark -
#pragma mark Table View Delegate Methods


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
	//row指点击中哪一行，从0开始
	//NSUInteger row = [indexPath row];
	//如下写上跳转代码
	NavAppDelegate *delegate=[[UIApplication sharedApplication]delegate];
	Num11 *nextController = [[Num11 alloc]
							initWithNibName:@"Num11" bundle:nil];
	
	//传one值到Num11
	//NSUInteger row = [indexPath row];
	One *one_trans = [oneArray objectAtIndex:indexPath.row];
	nextController.one=one_trans;
	//打印
	NSLog(@"num1 one name %@",one_trans.name);
	
	//页面跳转
	[delegate.navController pushViewController:nextController animated:YES];
}
@end
