//
//  One.h
//  Nav
//
//  Created by jone on 10-9-1.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface One : NSObject 
{
	NSString *name;
	NSString *name1;
	NSString *pic;
	NSString *quote1;
	NSString *name2;
	NSString *quote2;
	NSString *quote3;

}
@property(nonatomic,retain) NSString *name;
@property(nonatomic,retain) NSString *name1;
@property(nonatomic,retain) NSString *pic;
@property(nonatomic,retain) NSString *quote1;
@property(nonatomic,retain) NSString *name2;
@property(nonatomic,retain) NSString *quote2;
@property(nonatomic,retain) NSString *quote3;

+(id)initWithName:(NSString *)Name   Name1:(NSString *)Name1
			  Pic:(NSString *)Pic   Quote1:(NSString *)Quote1
			Name2:(NSString *)Name2 Quote2:(NSString *)Quote2
		   Quote3:(NSString *)Quote3;
+(id)initWithName:(NSString *)Name;
+(id)initWithOne:(One *)one;

       

@end
