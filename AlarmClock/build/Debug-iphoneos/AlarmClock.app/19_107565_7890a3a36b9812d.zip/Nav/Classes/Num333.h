//
//  Num333.h
//  Nav
//
//  Created by jone on 10-9-1.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Two.h"
#import "Num3.h"

@interface Num333 : UIViewController {
	UILabel  *label;
	UILabel  *label1;
	UITextView *text;
    int pageNumber;
	Two *two;
}

@property (nonatomic, retain) IBOutlet UILabel *label;
@property (nonatomic, retain) IBOutlet UILabel *label1;
@property (nonatomic, retain) IBOutlet UITextView *text;
@property (nonatomic, retain) Two *two;
- (id)initWithPageNumber:(int)page;

@end
