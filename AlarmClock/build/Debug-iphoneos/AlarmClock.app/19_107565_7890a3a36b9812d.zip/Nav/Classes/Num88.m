    //
//  Num88.m
//  Nav
//
//  Created by jone on 10-8-31.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Num88.h"

static NSArray *__pageControlColorList = nil;
@implementation Num88

@synthesize text;
@synthesize image;
@synthesize label;
// Creates the color list the first time this method is invoked. Returns one color object from the list.
+ (UIColor *)pageControlColorWithIndex:(NSUInteger)index 
{
    if (__pageControlColorList == nil)
	{
        __pageControlColorList = [[NSArray alloc] initWithObjects:[UIColor whiteColor], [UIColor whiteColor], [UIColor magentaColor],
                                  [UIColor blueColor], [UIColor orangeColor], [UIColor brownColor], [UIColor grayColor], nil];
    }
	
    // Mod the index by the list length to ensure access remains in bounds.
    return [__pageControlColorList objectAtIndex:index % [__pageControlColorList count]];
}

// Load the view nib and initialize the pageNumber ivar.
- (id)initWithPageNumber:(int)page 
{
    if (self = [super initWithNibName:@"Num88" bundle:nil]) 
	{
        pageNumber = page;
    }
    return self;
}

- (void)dealloc 
{
    [text release];
	[image release];
	[label release];
    [super dealloc];
}
/* pageNumberLabel.text = [NSString stringWithFormat:@"Page123321321321 %d", pageNumber + 1];
 self.view.backgroundColor = [MyViewController pageControlColorWithIndex:pageNumber];*/
// Set the label and background color when the view has finished loading.
- (void)viewDidLoad 
{    
	image.image = [UIImage imageNamed:@"logo1.png"];
	label.text=[NSString stringWithFormat:@""];
	if (pageNumber==0)
	{
		
		text.text = [NSString stringWithFormat:@"       云创科技有限公司以德为核心，以才为根本的积极向上的追求文化与品位的公司，自2004年创立以来，公司一直以孝顺、正直、共享、包容的做人准则和激情、创新、专注、价值的做事原则作为公司的企业文化，云创科技有限公司是专注于教育、健康生活领域的应用软件、游戏软件开发商，以互动、快乐、体验、教育的研究与开发理念完成了大批应用产品。在苹果的软件商店，公司所开发的ICREATE、古筝等产品获得了员工最爱和最热门产品评价。\n\n        云创科技有限公司是重视开发流程、重视软件质量的软件外包承接商，随着公司开发流程和质量保证体系不断完善，我们与大量的企事业单位建立了合作关系。\n\n       云创科技有限公司承前启后、继往开来，欢迎德才兼备之士的加盟；云创科技有限公司谦虚严谨、全心全力，为您提供最好的应用和服务。"];
		text.font = [UIFont italicSystemFontOfSize:25];
		
	}
	if (pageNumber==1) 
    {
	
	text.text = [NSString stringWithFormat:@"(Mobile Educational Entertainment Transfer) Studio is a positive and progressive company which highly values both moral and talent. Since its inception in 2004, this company has taken Filial Piety, Integrity, Participation and Catholicity as standards of life and Passion, Innovation, Absorption, Valuation as principles of work. MEET Studio devotes to delivering the best mobile apps to our users. We take education and healthcare seriously and try our best to build some great apps that could help to provide more interesting and interactive teaching materials as well as healthcare. Meanwhile, we integrate Chinese traditional couture into part of mobile apps, because we strive for high quality games with a strong focus on education and playability，such as Traditional Zither( 古筝), iCreate, Crazy Punching, Panda Learning and Eastern Lute. Originality is something we value highly at MEET Studio which shines through in products like Body Diary，Dressing Room and Stool UP!(便便UP！)for iPad and iPhone."];
	text.font = [UIFont italicSystemFontOfSize:25];
		

	}
	self.view.backgroundColor = [Num88 pageControlColorWithIndex:pageNumber];
}

@end
