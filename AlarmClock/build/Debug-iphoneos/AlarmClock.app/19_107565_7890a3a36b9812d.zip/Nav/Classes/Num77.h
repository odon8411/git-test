//
//  Num77.h
//  Nav
//
//  Created by jone on 10-8-31.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface Num77 : UIViewController 
{
	UILabel  *label;
	UIImageView *image;
    int pageNumber;
	
}

@property (nonatomic, retain) IBOutlet UILabel *label;
@property (nonatomic, retain) IBOutlet UIImageView *image;

- (id)initWithPageNumber:(int)page;

@end
