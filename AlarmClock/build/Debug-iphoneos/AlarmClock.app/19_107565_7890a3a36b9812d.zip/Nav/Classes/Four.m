    //
//  Four.m
//  Nav
//
//  Created by jone on 10-9-1.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Four.h"


@implementation Four
@synthesize name;
@synthesize name1;
@synthesize quote1;

+(id)initWithName:(NSString *)Name
{
	Four *four=[[[self alloc] init] autorelease];
	four.name=Name;
	return four;
}

+(id)initWithName:(NSString *)Name Name1:(NSString *)Name1
           Quote1:(NSString *)Quote1
{
	Four *four=[[[self alloc]init] autorelease];
	four.name=Name;
	four.name1=Name1;
	four.quote1=Quote1;
	return four;
}
+(id)initWithFour:(Four *)four
{
	Four *me=[[[self alloc] init] autorelease];
	me.name=four.name;
	me.name1=four.name1;
	return me;
}
@end
