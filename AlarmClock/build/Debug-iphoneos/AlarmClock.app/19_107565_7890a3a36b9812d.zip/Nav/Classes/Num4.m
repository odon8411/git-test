    //
//  Num4.m
//  Nav
//
//  Created by jone on 10-8-30.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Num4.h"
#import "Num44.h"
#import "Num444.h"
#import "NavAppDelegate.h"
#import "ThirdLevelViewController.h"
@implementation Num4
@synthesize controllers;

- (void)viewDidLoad
{
	self.title = @"成语小知识";
	NSMutableArray *array=[[NSMutableArray alloc]init];
	
	Num44 *num44 = [[Num44 alloc]
					initWithNibName:@"Num44" bundle:nil];
	num44.title = @"史上最牛的成语接龙";
	
	[array addObject:num44];
	[num44 release];
	
	Num444 *num444 = [[Num444 alloc] 
				  initWithNibName:@"Num444" bundle:[NSBundle mainBundle]];
	num444.title = @"中华历史成语典故与人物";
	
	[array addObject:num444];
	[num444 release];
	self.controllers = array;
	[array release];
	[super viewDidLoad];
	
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning 
{
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
}


- (void)dealloc
{
	[controllers release];
	[super dealloc];
}

#pragma mark -
#pragma mark Table Data Source Methods
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return [self.controllers count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
	
	static NSString *TopLevelCellIdentifier = @"成语小知识";
	
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:TopLevelCellIdentifier];
	if (cell == nil)
	{
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:TopLevelCellIdentifier] autorelease];
	}
	// Configure the cell
	NSUInteger row = [indexPath row];
	ThirdLevelViewController *controller = [controllers objectAtIndex:row];
	cell.text = controller.title;
	
	return cell;
}

#pragma mark -
#pragma mark Table View Delegate Methods


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
	NSUInteger row = [indexPath row];
	ThirdLevelViewController *nextController = [self.controllers objectAtIndex:row];
	
	NavAppDelegate *delegate = [[UIApplication sharedApplication] delegate];
	[delegate.navController pushViewController:nextController animated:YES];
}
@end

