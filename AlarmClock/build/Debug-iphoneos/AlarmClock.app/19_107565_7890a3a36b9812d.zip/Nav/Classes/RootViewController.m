    //
//  RootViewController.m
//  Nav
//
//  Created by jone on 10-8-30.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "RootViewController.h"
#import "SecondLevelViewController.h"
#import "NavAppDelegate.h"
#import "Num1.h"
#import "Num2.h"
#import "Num3.h"
#import "Num4.h"
#import "Num5.h"
#import "Num6.h"
#import "Num7.h"
#import "Num8.h"

@implementation RootViewController
@synthesize controllers;



//定义8个数组 显示在table
- (void)viewDidLoad 
{   
	self.title = @"中华成语经典";
	NSMutableArray *array = [[NSMutableArray alloc] init];
	
     //to num1
	Num1 *num1 = [[Num1 alloc] 
				  initWithStyle:UITableViewStylePlain];
	num1.title = @"经典成语故事";
	
	[array addObject:num1];
	[num1 release];
	
	
   //to  num2
	Num2 *num2 = [[Num2 alloc] 
				  initWithStyle:UITableViewStylePlain];
	num2.title = @"成语与物理";
	
	[array addObject:num2];
	[num2 release];
	
	
	//to num3
	Num3 *num3 = [[Num3 alloc] 
				  initWithStyle:UITableViewStylePlain];
	num3.title = @"成语与化学";
	
	[array addObject:num3];
	[num3 release];
	
	
	//to num4
	Num4 *num4 = [[Num4 alloc] 
				  initWithStyle:UITableViewStylePlain];
	num4.title = @"成语小知识";
		[array addObject:num4];
	[num4 release];
	
	
	// to num5
	Num5 *num5 = [[Num5 alloc] 
				  initWithNibName:@"Num5" bundle:[NSBundle mainBundle]];
	num5.title = @"成语之最";
	
	[array addObject:num5];
	[num5 release];
	
	//to  num6
	Num6 *num6 = [[Num6 alloc] 
				  initWithNibName:@"Num6" bundle:[NSBundle mainBundle]];
	num6.title = @"中华成语渊源";

	[array addObject:num6];
	[num6 release];
	
	
	// to num7
	Num7 *num7 = [[Num7 alloc] 
				  initWithNibName:@"Num7" bundle:[NSBundle mainBundle]];
	num7.title = @"书法欣赏";
		[array addObject:num7];
	[num7 release];
	
	
	// to num8
	Num8 *num8 = [[Num8 alloc] 
				  initWithNibName:@"Num8" bundle:[NSBundle mainBundle]];
	num8.title = @"关于我们";
		[array addObject:num8];
	[num8 release];
	
	
	self.controllers = array;
	[array release];
	[super viewDidLoad];
	
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	// Return YES for supported orientations
	return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning 
{
	[super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
	// Release anything that's not essential, such as cached data
}


- (void)dealloc 
{
	[controllers release];
	[super dealloc];
}

#pragma mark -
#pragma mark Table Data Source Methods
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return [self.controllers count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
	
	static NSString *TopLevelCellIdentifier = @"中华成语经典";
	
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:TopLevelCellIdentifier];
	if (cell == nil)
	{
		cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:TopLevelCellIdentifier] autorelease];
	}
	// 到secondlevelviewcontroller 二级跳转页面
	NSUInteger row = [indexPath row];
	SecondLevelViewController *controller = [controllers objectAtIndex:row];
	cell.text = controller.title;

	return cell;
}

#pragma mark -
#pragma mark Table View Delegate Methods


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
	NSUInteger row = [indexPath row];
	SecondLevelViewController *nextController = [self.controllers objectAtIndex:row];
	
	NavAppDelegate *delegate = [[UIApplication sharedApplication] delegate];
	[delegate.navController pushViewController:nextController animated:YES];
}
@end

